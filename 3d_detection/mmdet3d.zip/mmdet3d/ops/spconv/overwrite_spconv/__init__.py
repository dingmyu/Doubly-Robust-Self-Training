# Copyright (c) OpenMMLab. All rights reserved.
from .write_spconv2 import register_spconv2

__all__ = ['register_spconv2']
