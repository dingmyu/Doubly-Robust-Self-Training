# Copyright (c) OpenMMLab. All rights reserved.
from .prediction_kitti_to_waymo import KITTI2Waymo

__all__ = ['KITTI2Waymo']
